#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include "devices.h"
#include "generic_devices.h"
#include <string.h>
#include <graphics.h>
#include <drv_ioport.h>
#include <drv_terminal.h>
#include <canvas.h>
#include <touchscreen.h>
#include <pointer.h>
#include <stdbool.h>
#include <drv_led.h>
#include "led_info.h"
#define WIDTH 320
#define HEIGHT 240

graphics_t * display;   //DECLARACION DEL PUNTERO display.
canvas_t * canvas;
ioport_t* dip;
terminal_t* term;
pointer_state_t * pointer_state;
pointer_t* punt;
color_t  color;
color_t  colorcua1;
led_t * leds;
touchscreen_t* touch;
touchscreen_callback_t callback;
int b=3, figure=0,c=3,colorcua1=0;

static void draw_mark(int x, int y, int width, int height, void *vp);
char *cal1 = "Touch screen at marker";

void update_leds (const uint32_t * col_buff);
void set_all_leds (uint32_t value);
static void draw_mark(int x, int y, int width, int height, void *vp);

void main(void){

touch= touchscreen_open(TOUCHSCREEN_1);
display = graphics_open(GRAPHICS_1); //  Devuelte el puntero del servicio en caso de ser inicializado
leds = led_open(DRV_LED_1);
led_turn_all_off(leds);
punt= pointer_open(POINTER_1);
term= terminal_open(DRV_TERMINAL_1);
dip= ioport_open(DIP);
canvas = graphics_get_visible_canvas(display);



touchscreen_set_callback(touch, draw_mark, canvas);
while(!touchscreen_calibrate(touch, WIDTH, HEIGHT));
    {
        set_all_leds(0xFF0000); // If Touchscreen can't calibrate RED ALERT!
    }
    led_turn_all_off(leds);

graphics_fill_canvas( canvas, WHITE);
graphics_fill_rect( canvas, 0, 0, 46, 37, RED);
graphics_fill_rect( canvas, 280, 37, 46, 36, BLACK);
graphics_fill_triangle( canvas, 47, 36, 69, 0, 91, 36, LAWNGREEN);
graphics_fill_circle(canvas, 114, 18, 17, YELLOW);
graphics_fill_rect( canvas, 138, 0, 46, 36, LIGHTCYAN);
graphics_fill_rect( canvas, 185, 0, 46, 36, LIGHTCYAN);
graphics_fill_rect( canvas, 232, 0, 46, 36, LIGHTCYAN);
graphics_draw_line(canvas, 139, 36, 180, 0, RED);
graphics_draw_line(canvas, 139, 0, 180, 36, RED);
graphics_draw_line(canvas, 185, 36, 231, 0, RED);
graphics_draw_line(canvas, 185, 0, 231, 36, RED);
graphics_draw_line(canvas, 232, 36, 278, 0, RED);
graphics_draw_line(canvas, 232, 0, 278, 36, RED);
graphics_draw_char(canvas, 157, 15, 0x31, &bitstreamverasans10,  BLACK, FS_NONE);
graphics_draw_char(canvas, 204, 15, 0x32, &bitstreamverasans10,  BLACK, FS_NONE);
graphics_draw_char(canvas, 250, 15, 0x33,&bitstreamverasans10,  BLACK, FS_NONE);
graphics_draw_line(canvas, 280, 73, 280, 110, BLACK);
graphics_draw_line(canvas, 280, 110,320, 110, BLACK);
graphics_draw_line(canvas, 280, 110, 280, 146, BLACK);
graphics_draw_line(canvas, 280, 146,320, 146, BLACK);
graphics_draw_line(canvas, 280, 146, 280, 182, BLACK);
graphics_draw_line(canvas, 280, 182,320, 182, BLACK);
while(1){


         graphics_set_visible_canvas(display, canvas);

            while(1){

            if (pointer_update(punt, pointer_state)) {
               if( pointer_state->x>0 && pointer_state->x<280 && pointer_state->y>44 && pointer_state->y<240) {
                   set_all_leds(graphics_get_pixel(canvas, pointer_state->x, pointer_state->y));
                   if(figure==0){
                   graphics_fill_circle( canvas, pointer_state->x, pointer_state->y,c, color);}
                   if(figure==1){
                   graphics_fill_rect( canvas, pointer_state->x, pointer_state->y,2*c,2*c, color);}
                   if(figure==2){
                   graphics_fill_triangle( canvas, pointer_state->x, pointer_state->y,(pointer_state->x)+2*c,(pointer_state->y),(pointer_state->x)+c,(pointer_state->y)+2*c, color);}
                   graphics_set_visible_canvas(display, canvas);
                   led_set_all_on_intensity(leds, 120);
               }
               if( pointer_state->x>0 && pointer_state->x<46 && pointer_state->y>0 && pointer_state->y<36){
               figure=1;}
               if( pointer_state->x>47 && pointer_state->x<91 && pointer_state->y>0 && pointer_state->y<36){
               figure=2;}
               if( pointer_state->x>92 && pointer_state->x<138 && pointer_state->y>0 && pointer_state->y<36){
               figure=0;}
               if( pointer_state->x>138 && pointer_state->x<184 && pointer_state->y>0 && pointer_state->y<36){
               c=1*b;}
               if( pointer_state->x>185 && pointer_state->x<231 && pointer_state->y>0 && pointer_state->y<36){
               c=2*b;}
               if( pointer_state->x>232 && pointer_state->x<278 && pointer_state->y>0 && pointer_state->y<36){
               c=3*b;}
               if( pointer_state->x>280 && pointer_state->x<340 && pointer_state->y>0 && pointer_state->y<36){
               color=WHITE;}
               if( pointer_state->x>280 && pointer_state->x<340 && pointer_state->y>37 && pointer_state->y<73){
               color=BLACK;}
            if(ioport_get_value(dip, 0)!=30){
                colorcua1=colorcua1++;}
            graphics_fill_rect( canvas, 281, 74, 39, 109, colorcua1);
            }
            }

            //color=graphics_get_pixel(canvas2, pointer_state->x, pointer_state->y);}
         }
}

static void draw_mark(int x, int y, int width, int height, void *vp)
{
     graphics_draw_circle(canvas, x, y, 10, 0xff00ff);
     graphics_draw_line(canvas, x - 15, y, x + 15, y, 0x00ffff);
     graphics_draw_line(canvas, x, y - 15, x, y + 15, 0x00ffff);
     graphics_draw_string(canvas, 50, 50, cal1, NULL, 0xffffff, 0);
     graphics_set_visible_canvas(display, canvas);

}


void set_all_leds (uint32_t value)
{
    for(int i = 0; i <0xFFFFFFFF; )
    {
        led_set_intensity(leds, i++, (uint8_t)(value>>16)); // Red
        led_set_intensity(leds, i++, (uint8_t)(value>>8));  // Green
        led_set_intensity(leds, i++, (uint8_t)value);       // Blue
    }
}

 /*
 graphics_t * display;   //DECLARACION DEL PUNTERO display.
canvas_t * canvas;
canvas_t * canvas1;
canvas_t * canvas2;
ioport_t* dip;
terminal_t* term;
pointer_state_t * pointer_state;
pointer_t* punt;
color_t  color;
color_t  color2;
led_t * leds;
touchscreen_t* touch;
touchscreen_callback_t callback;
int b=3, figure=0,c=3;

static void draw_mark(int x, int y, int width, int height, void *vp);
char *cal1 = "Touch screen at marker";
extern __no_sdata graphics_bitmap_t _lc_ub_color_bmp; //Imagen
extern __no_sdata graphics_bitmap_t _lc_ue_color_bmp;
graphics_bitmap_t * bmp = &_lc_ub_color_bmp;

void update_leds (const uint32_t * col_buff);
void set_all_leds (uint32_t value);
static void draw_mark(int x, int y, int width, int height, void *vp);

void main(void){

touch= touchscreen_open(TOUCHSCREEN_1);
display = graphics_open(GRAPHICS_1); //  Devuelte el puntero del servicio en caso de ser inicializado
leds = led_open(DRV_LED_1);
led_turn_all_off(leds);
punt= pointer_open(POINTER_1);
term= terminal_open(DRV_TERMINAL_1);
dip= ioport_open(DIP);
canvas = graphics_get_visible_canvas(display);
canvas1 = graphics_get_visible_canvas(display);
canvas2 = graphics_get_visible_canvas(display);


touchscreen_set_callback(touch, draw_mark, canvas);
while(!touchscreen_calibrate(touch, WIDTH, HEIGHT));
    {
        set_all_leds(0xFF0000); // If Touchscreen can't calibrate RED ALERT!
    }
    led_turn_all_off(leds);

graphics_fill_canvas( canvas, WHITE);
graphics_fill_rect( canvas, 0, 0, 46, 37, RED);
graphics_fill_triangle( canvas, 47, 36, 69, 0, 91, 36, LAWNGREEN);
graphics_fill_circle(canvas, 114, 18, 17, YELLOW);
graphics_fill_rect( canvas, 138, 0, 46, 36, LIGHTCYAN);
graphics_fill_rect( canvas, 185, 0, 46, 36, LIGHTCYAN);
graphics_fill_rect( canvas, 232, 0, 46, 36, LIGHTCYAN);
graphics_draw_line(canvas, 139, 36, 180, 0, RED);
graphics_draw_line(canvas, 139, 0, 180, 36, RED);
graphics_draw_line(canvas, 185, 36, 231, 0, RED);
graphics_draw_line(canvas, 185, 0, 231, 36, RED);
graphics_draw_line(canvas, 232, 36, 278, 0, RED);
graphics_draw_line(canvas, 232, 0, 278, 36, RED);
graphics_draw_char(canvas, 157, 15, 0x31, &bitstreamverasans10,  BLACK, FS_NONE);
graphics_draw_char(canvas, 204, 15, 0x32, &bitstreamverasans10,  BLACK, FS_NONE);
graphics_draw_char(canvas, 250, 15, 0x33,&bitstreamverasans10,  BLACK, FS_NONE);


while(1){


         graphics_set_visible_canvas(display, canvas);
         line:
            while(ioport_get_value(dip, 0)!=30){

            if (pointer_update(punt, pointer_state)) {
               if( pointer_state->x>0 && pointer_state->x<320 && pointer_state->y>44 && pointer_state->y<240) {
                   set_all_leds(graphics_get_pixel(canvas, pointer_state->x, pointer_state->y));
                   if(figure==0){
                   graphics_fill_circle( canvas, pointer_state->x, pointer_state->y,c, color);}
                   if(figure==1){
                   graphics_fill_rect( canvas, pointer_state->x, pointer_state->y,2*c,2*c, color);}
                   if(figure==2){
                   graphics_fill_triangle( canvas, pointer_state->x, pointer_state->y,(pointer_state->x)+2*c,(pointer_state->y),(pointer_state->x)+c,(pointer_state->y)+2*c, color);}
                   graphics_set_visible_canvas(display, canvas);
                   led_set_all_on_intensity(leds, 120);
               }
               if( pointer_state->x>0 && pointer_state->x<46 && pointer_state->y>0 && pointer_state->y<36){
               figure=1;}
               if( pointer_state->x>47 && pointer_state->x<91 && pointer_state->y>0 && pointer_state->y<36){
               figure=2;}
               if( pointer_state->x>92 && pointer_state->x<138 && pointer_state->y>0 && pointer_state->y<36){
               figure=0;}
               if( pointer_state->x>138 && pointer_state->x<184 && pointer_state->y>0 && pointer_state->y<36){
               c=1*b;}
               if( pointer_state->x>185 && pointer_state->x<231 && pointer_state->y>0 && pointer_state->y<36){
               c=2*b;}
               if( pointer_state->x>232 && pointer_state->x<278 && pointer_state->y>0 && pointer_state->y<36){
               c=3*b;}
               if( pointer_state->x>280 && pointer_state->x<340 && pointer_state->y>0 && pointer_state->y<36){
               color=WHITE;}
            }
            }
            canvas1=canvas_copy(canvas);
            while(ioport_get_value(dip, 0)==30){

            graphics_draw_bitmap(canvas2, bmp, 0, 0, 320, 240, 0);
            graphics_set_visible_canvas(display, canvas2);
            if (pointer_update(punt, pointer_state)) {
            set_all_leds(graphics_get_pixel(canvas2, pointer_state->x, pointer_state->y));
            color=graphics_get_pixel(canvas2, pointer_state->x, pointer_state->y);}
            }

          graphics_fill_canvas( canvas2, WHITE);
          graphics_set_visible_canvas(display, canvas1);
          goto line;
         }
}

static void draw_mark(int x, int y, int width, int height, void *vp)
{
     graphics_draw_circle(canvas, x, y, 10, 0xff00ff);
     graphics_draw_line(canvas, x - 15, y, x + 15, y, 0x00ffff);
     graphics_draw_line(canvas, x, y - 15, x, y + 15, 0x00ffff);
     graphics_draw_string(canvas, 50, 50, cal1, NULL, 0xffffff, 0);
     graphics_set_visible_canvas(display, canvas);

}


void set_all_leds (uint32_t value)
{
    for(int i = 0; i <0xFFFFFFFF; )
    {
        led_set_intensity(leds, i++, (uint8_t)(value>>16)); // Red
        led_set_intensity(leds, i++, (uint8_t)(value>>8));  // Green
        led_set_intensity(leds, i++, (uint8_t)value);       // Blue
    }
}
*/









