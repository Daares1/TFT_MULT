/*#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include "devices.h"
#include "generic_devices.h"
#include <string.h>
#include <graphics.h>
#include <drv_ioport.h>
#include <drv_terminal.h>
#include <canvas.h>
#include <touchscreen.h>
#include <pointer.h>
#include <stdbool.h>
#include <drv_led.h>
#include "led_info.h"

#define WIDTH 320
#define HEIGHT 240

graphics_t * display;   //DECLARACION DEL PUNTERO display.
canvas_t * canvas;
canvas_t * canvas1;
canvas_t * canvas2;
ioport_t* dip;
terminal_t* term;
pointer_state_t * pointer_state;
pointer_t* punt;
color_t  color;
color_t  color2;
led_t * leds;
touchscreen_t* touch;
touchscreen_callback_t callback;

static void draw_mark(int x, int y, int width, int height, void *vp);

char *cal1 = "Touch screen at marker";
char *cal2 = "Calibration done";
char *cal3 = "+1";
char *cal4 = "+2";
char *cal5 = "+3";



extern __no_sdata graphics_bitmap_t _lc_ub_bar_bmp; //Imagen
extern __no_sdata graphics_bitmap_t _lc_ue_bar_bmp;
graphics_bitmap_t * bmp = &_lc_ub_bar_bmp;


void main(void){

touch= touchscreen_open(TOUCHSCREEN_1);
display = graphics_open(GRAPHICS_1); //  Devuelte el puntero del servicio en caso de ser inicializado
canvas = graphics_get_visible_canvas(display);
canvas2 = graphics_get_visible_canvas(display);
canvas1 = graphics_get_visible_canvas(display);

leds = led_open(DRV_LED_1);
 led_turn_all_off(leds);
punt= pointer_open(POINTER_1);
term= terminal_open(DRV_TERMINAL_1);
dip= ioport_open(DIP);
 int a=0,c=0,b=4;
touchscreen_set_callback(touch, draw_mark, canvas);
while(!touchscreen_calibrate(touch, WIDTH, HEIGHT));
graphics_fill_canvas(canvas, 0x080008);

graphics_fill_circle(canvas, 160, 120, 400, WHITE);
graphics_set_visible_canvas(display, canvas);

graphics_draw_bitmap(canvas, bmp, 0, 0, 320, 37, 0);
graphics_set_visible_canvas(display, canvas);

graphics_fill_rect(canvas, 290, 37, 30, 200,WHITE);
graphics_set_visible_canvas(display, canvas);

graphics_fill_circle(canvas, 305, 60, 5, BLACK);
graphics_set_visible_canvas(display, canvas);

graphics_fill_rect(canvas, 305, 80, 10, 10,BLACK);
graphics_set_visible_canvas(display, canvas);

graphics_draw_line(canvas, 305,90, 315, 80,WHITE); //LA EQUIS
graphics_set_visible_canvas(display, canvas);

graphics_draw_line(canvas, 315,90, 305, 80, WHITE);
graphics_set_visible_canvas(display, canvas);

while(1){

if (pointer_update(punt, pointer_state)) {
if( pointer_state->x>0 && pointer_state->x<320 && pointer_state->y>0 && pointer_state->y<37)

color=graphics_get_pixel(canvas2, pointer_state->x, pointer_state->y);

}




while( color!=NULL && pointer_state->x>0 && pointer_state->x<290 && pointer_state->y>40 && pointer_state->y<240 ){

if (pointer_update(punt, pointer_state))  {


graphics_fill_circle( canvas, pointer_state->x, pointer_state->y,b, color);
graphics_set_visible_canvas(display, canvas);
led_set_all_on_intensity(leds, 120);



}

 if (pointer_update(punt, pointer_state)) {
 while(ioport_get_value(dip, 0)==29  ){


graphics_fill_rect(canvas, 290, 200, 30, 40,color2);
graphics_set_visible_canvas(display, canvas);
color2=color2+3;
if (pointer_update(punt, pointer_state))  {
if( pointer_state->x>290 && pointer_state->x<320 && pointer_state->y>200 && pointer_state->y<240){
color=graphics_get_pixel(canvas2, pointer_state->x, pointer_state->y);

}
}
 }

 }
 if (pointer_update(punt, pointer_state)) {
 while(ioport_get_value(dip, 0)==30 ){


graphics_fill_rect(canvas, 290, 200, 30, 40,color2);
graphics_set_visible_canvas(display, canvas);
color2=color2-3;
if (pointer_update(punt, pointer_state))  {
if( pointer_state->x>290 && pointer_state->x<320 && pointer_state->y>200 && pointer_state->y<240){
color=graphics_get_pixel(canvas2, pointer_state->x, pointer_state->y);

}
}

 }
 }
}




}

}

static void draw_mark(int x, int y, int width, int height, void *vp)
{
     graphics_draw_circle(canvas, x, y, 10, 0xff00ff);
     graphics_draw_line(canvas, x - 15, y, x + 15, y, 0x00ffff);
     graphics_draw_line(canvas, x, y - 15, x, y + 15, 0x00ffff);
     graphics_draw_string(canvas, 50, 50, cal1, NULL, 0xffffff, 0);
     graphics_set_visible_canvas(display, canvas);
}
/*
while(1){

    line:
  if (pointer_update(punt, pointer_state))  {

 while( ioport_get_value(dip, 0)==29){
graphics_draw_bitmap(canvas, bmp, 0, 0, 320, 240, 0);
graphics_set_visible_canvas(display, canvas);
if (pointer_update(punt, pointer_state)) {
color=graphics_get_pixel(canvas, pointer_state->x, pointer_state->y);
 printf("el color es %p ",color);
}

 }

 graphics_fill_circle(canvas, 160, 120, 400, WHITE);
 graphics_set_visible_canvas(display, canvas);


while( color!=NULL  ){

            if  ( ioport_get_value(dip, 0)==29) {

            goto line;
            }




                  if (pointer_update(punt, pointer_state))  {

                  graphics_fill_circle( canvas, pointer_state->x, pointer_state->y,5, color);
                  graphics_set_visible_canvas(display, canvas);
                  }

}
}









}

}


static void draw_mark(int x, int y, int width, int height, void *vp)
{
     graphics_draw_circle(canvas, x, y, 10, 0xff00ff);
     graphics_draw_line(canvas, x - 15, y, x + 15, y, 0x00ffff);
     graphics_draw_line(canvas, x, y - 15, x, y + 15, 0x00ffff);
     graphics_draw_string(canvas, 50, 50, cal1, NULL, 0xffffff, 0);
     graphics_set_visible_canvas(display, canvas);
}





           */

                              



  #include <gl/gl.h>
#include <gl/device.h>
#include <math.h>
#define ABS( a )        (((a) > 0) ? (a) : -(a))
#define MOUSE               12
#define TABLET              13
#define DRAWLINE             2
#define NEWCOLOR             3
#define CLEAR                4
#define NEWSIZE              5
#define MOUSEXMAP(x)        ( (100.0*((x)-xorg))/(xsize) )
#define MOUSEYMAP(y)        ( (100.0*((y)-yorg))/(ysize) )
#define BPSCALE 16.0
struct event {
   struct event *next;
   int func;
   float arg1;
   float arg2;
   float arg3;
   float arg4;
};
int xsize, ysize;
int xorg, yorg;
int mx, my;
int bpx, bpy;
int mmiddle, mleft;
int curcolor = 7;
int lastcurcolor = 7;
float curx, cury, cursize;
int curdev = MOUSE;
struct event *histstart = 0;
struct event *histend = 0;
float xpos, ypos;
int pendown;
int brushsides;
float brushcoords[30][2];
int menu;
main()
{
   cursize = 1.0;
   prefposition(XMAXSCREEN/4,XMAXSCREEN*3/4,YMAXSCREEN/4,
       YMAXSCREEN*3/4);
   winopen("paint");
   menu = defpup("paint %t|mouse|tablet");
   makebrush();
   makeframe();
   getinput();
}
getinput()
{
   Device dev;
   short val;
   float x, y;
   while(TRUE) {
      do {
         dev = qread(&val);
         switch (dev) {
         case MOUSEX:
            mx = val;
            if (curdev == MOUSE)
               xpos = MOUSEXMAP(val);
            break;
         case MOUSEY:
            my = val;
            if (curdev == MOUSE)
               ypos = MOUSEYMAP(val);
            break;
         case BPADX:
            bpx = val;
            if (curdev == TABLET)
               xpos = val/BPSCALE;
            break;
         case BPADY:
            bpy = val;
            if (curdev == TABLET)
               ypos = val/BPSCALE;
            break;
         case BPAD0:
            if (curdev == TABLET)
               pendown = val;
            if (val) {
               curx = xpos = bpx/BPSCALE;
               cury = ypos = bpy/BPSCALE;
            }
            break;
         case MENUBUTTON:
            if(val) {
               switch (dopup(menu)) {
               case 1:
                  curdev = MOUSE;
                  break;
               case 2:
                  curdev = TABLET;
                  break;
               }
            }
            break;
         case MIDDLEMOUSE:
            mmiddle = val;
            if (mmiddle) {
               clearscreen();
               history(CLEAR);
            }
            break;
         case LEFTMOUSE:
            mleft = val;
            if (mleft) {
               if (!inside(mx-xorg, my-yorg,
                   0, xsize, 0, ysize, 0)) {
                  newcolor(getapixel(mx,my));
                  history(NEWCOLOR,(float)curcolor);
               }
            }
            if (curdev == MOUSE) {
               pendown = val;
               curx = xpos = MOUSEXMAP(mx);
               cury = ypos = MOUSEYMAP(my);
            }
            break;
         case REDRAW:
            makeframe();
            replay();
            break;
         case ESCKEY:
            gexit();
            exit(0);
            break;
         }
      } while (qtest());
      if (pendown) {
         x = xpos;
         y = ypos;
         drawbrush(x,y,curx,cury);
         history(DRAWLINE,x,y,curx,cury);
         curx = x;
         cury = y;
      }
   }
}
clearscreen()
{
   color(curcolor);
   clear();
}
newcolor(c)
int c;
{
   lastcurcolor = curcolor;
   curcolor = c;
   paintport();
}
makeframe()
{
   qdevice(ESCKEY);
   qdevice(MOUSEX);
   qdevice(MOUSEY);
   qdevice(MENUBUTTON);
   qdevice(MIDDLEMOUSE);
   qdevice(LEFTMOUSE);
   qdevice(BPADX);
   qdevice(BPADY);
   qdevice(BPAD0);
   getsize(&xsize,&ysize);
   getorigin(&xorg,&yorg);
   paintport();
   newcolor(0);
   clearscreen();
   newcolor(255);
   newcolor(128+32);
}
paintport()
{
   viewport(0,xsize-1,0,ysize);
   ortho2(-0.5,99.5,-0.5,99.5);
}
inside(x,y,xmin,xmax,ymin,ymax,fudge)
int x, y, xmin, xmax, ymin, ymax, fudge;
{
   if (x>xmin-fudge && x<xmax+fudge &&
       y>ymin-fudge && y<ymax+fudge)
      return 1;
   else
      return 0;
}
makebrush()
{
   int i;
   brushsides = 4;
   brushcoords[0][0] = -0.6;
   brushcoords[0][1] = -0.2;
   brushcoords[1][0] = -0.6;
   brushcoords[1][1] = -0.4;
   brushcoords[2][0] =  0.6;
   brushcoords[2][1] =  0.2;
   brushcoords[3][0] =  0.6;
   brushcoords[3][1] =  0.4;
   for (i=0; i<brushsides; i++) {
      brushcoords[i][0] = 0.5*brushcoords[i][0];
      brushcoords[i][1] = 0.5*brushcoords[i][1];
   }
}
drawbrush(x,y,ox,oy)
float x, y, ox, oy;
{
   register int i, n;
   register float dx, dy;
   float quad[4][2];
   float delta;
   int c;
   dx = ox-x;
   dy = oy-y;
   if (lastcurcolor != curcolor) {
      delta = sqrt(dx*dx+dy*dy);
      if (delta<0.001)
         return;
      c = (int) (curcolor + (lastcurcolor-curcolor) *
          (ABS(dx)/delta) );
      color(c);
   }
   else
      color(curcolor);
   pushmatrix();
   translate(x,y,0.0);
   for (i=0; i<brushsides; i++) {
      n = (i+1) % brushsides;
      quad[0][0] = brushcoords[i][0];
      quad[0][1] = brushcoords[i][1];
      quad[1][0] = brushcoords[n][0];
      quad[1][1] = brushcoords[n][1];
      quad[2][0] = quad[1][0]+dx;
      quad[2][1] = quad[1][1]+dy;
      quad[3][0] = quad[0][0]+dx;
      quad[3][1] = quad[0][1]+dy;
      polf2(4,quad);
   }
   polf2(brushsides,brushcoords);
   popmatrix();
}
history(func,arg1,arg2,arg3,arg4)
int func;
float arg1, arg2, arg3, arg4;
{
   register struct event *e, *n;
   e = (struct event *)malloc(sizeof(struct event));
   switch (func) {
   case CLEAR:
      zaphistory();
      history(NEWCOLOR,(float)curcolor);
      break;
   case NEWCOLOR:
   case DRAWLINE:
      e->func = func;
      e->arg1 = arg1;
      e->arg2 = arg2;
      e->arg3 = arg3;
      e->arg4 = arg4;
      e->next = 0;
      if (!histstart) {
         histstart = histend = e;
      }
      else {
         histend->next = e;
         histend = e;
      }
      break;
   }
}
zaphistory()
{
   register struct event *e, *n;
   e = histstart;
   while (e) {
      n = e->next;
      free(e);
      e = n;
   }
   histstart = histend = 0;
}
replay()
{
   register struct event *e;
   register int i;
   i = 0;
   e = histstart;
   while (e) {
      switch (e->func) {
      case NEWCOLOR:
         newcolor((int)e->arg1);
         break;
      case DRAWLINE:
         drawbrush(e->arg1,e->arg2,e->arg3,e->arg4);
         break;
      case CLEAR:
         clearscreen();
         break;
      }
      e = e->next;
      i++;
   }
}
/*
 *        getapixel -
 *                Read a pixel from a specific screen location.
 *
 */
getapixel(mousex, mousey)
short mousex, mousey;
{
   short pixel;
   int   xmin, ymin;    /* Convert position to window relative coordinates */
   getorigin(&xmin, &ymin);
   mousex -= xmin;
   mousey -= ymin;
   rectread(mousex, mousey, mousex+1, mousey+1, &pixel);
   return(pixel);
}














